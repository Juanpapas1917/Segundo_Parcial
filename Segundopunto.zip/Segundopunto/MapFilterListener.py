# Generated from MapFilter.g4 by ANTLR 4.13.0
from antlr4 import *
if "." in __name__:
    from .MapFilterParser import MapFilterParser
else:
    from MapFilterParser import MapFilterParser

# This class defines a complete listener for a parse tree produced by MapFilterParser.
class MapFilterListener(ParseTreeListener):

    # Enter a parse tree produced by MapFilterParser#program.
    def enterProgram(self, ctx:MapFilterParser.ProgramContext):
        pass

    # Exit a parse tree produced by MapFilterParser#program.
    def exitProgram(self, ctx:MapFilterParser.ProgramContext):
        pass


    # Enter a parse tree produced by MapFilterParser#statement.
    def enterStatement(self, ctx:MapFilterParser.StatementContext):
        pass

    # Exit a parse tree produced by MapFilterParser#statement.
    def exitStatement(self, ctx:MapFilterParser.StatementContext):
        pass


    # Enter a parse tree produced by MapFilterParser#expression.
    def enterExpression(self, ctx:MapFilterParser.ExpressionContext):
        pass

    # Exit a parse tree produced by MapFilterParser#expression.
    def exitExpression(self, ctx:MapFilterParser.ExpressionContext):
        pass


    # Enter a parse tree produced by MapFilterParser#mapExpr.
    def enterMapExpr(self, ctx:MapFilterParser.MapExprContext):
        pass

    # Exit a parse tree produced by MapFilterParser#mapExpr.
    def exitMapExpr(self, ctx:MapFilterParser.MapExprContext):
        pass


    # Enter a parse tree produced by MapFilterParser#filterExpr.
    def enterFilterExpr(self, ctx:MapFilterParser.FilterExprContext):
        pass

    # Exit a parse tree produced by MapFilterParser#filterExpr.
    def exitFilterExpr(self, ctx:MapFilterParser.FilterExprContext):
        pass


    # Enter a parse tree produced by MapFilterParser#function_name.
    def enterFunction_name(self, ctx:MapFilterParser.Function_nameContext):
        pass

    # Exit a parse tree produced by MapFilterParser#function_name.
    def exitFunction_name(self, ctx:MapFilterParser.Function_nameContext):
        pass


    # Enter a parse tree produced by MapFilterParser#iterable_name.
    def enterIterable_name(self, ctx:MapFilterParser.Iterable_nameContext):
        pass

    # Exit a parse tree produced by MapFilterParser#iterable_name.
    def exitIterable_name(self, ctx:MapFilterParser.Iterable_nameContext):
        pass



del MapFilterParser